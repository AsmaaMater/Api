import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.*;

public class UserCreationTest {

    private static final String BASE_URL = "https://reqres.in/api/users";

    @Test
    public void testUserCreation() {
        // Step 1: Create the JSON object for user data
        String jsonBody = "{ \"name\": \"John Doe\", \"job\": \"Software Engineer\" }";

        // Step 2 :Send the POST request
        Response response = given()
                .contentType("application/json")
                .body(jsonBody)
                .when()
                .post(BASE_URL);

        // Step 3 :Assert that the response status code is 201 (Created)
        assertEquals(201, response.getStatusCode());


        // Step 4: Validate the response body
        Integer id = response.jsonPath().getInt("id");
        String name = response.jsonPath().getString("name");
        String job = response.jsonPath().getString("job");

        assertNotNull(id);
        assertEquals("John Doe", name);
        assertEquals("Software Engineer", job);

        assertNotNull(id, "User ID should not be null");
        assertEquals("John Doe", name, "User name does not match");
        assertEquals("Software Engineer", job, "User job does not match");
    }
}